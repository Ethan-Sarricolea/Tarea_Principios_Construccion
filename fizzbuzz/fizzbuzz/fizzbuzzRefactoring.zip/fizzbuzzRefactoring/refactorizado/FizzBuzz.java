/**
 * Interfaz de FizzBuzz
 */

interface FizzBuzz {
    void print(int from, int to);
}